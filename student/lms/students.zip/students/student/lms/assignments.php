<?php include($_SERVER['DOCUMENT_ROOT'] . '/includes/header-top.php'); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/includes/header-bottom.php'); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/includes/menu.php'); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/includes/topbar.php'); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/includes/footer-top.php'); ?>
<div class="page-container ">
  <!-- <div class="page-content-wrapper "> -->
    <div class="content ">
      <div class="jumbotron" data-pages="parallax">
        <div class=" container-fluid sm-p-l-0 sm-p-r-0">
        </div>
      </div>
      <div class=" container-fluid">
        <div class="card card-transparent">
          <div class="card-header">
            <?php 
              ?>
            <div class="pull-right">
              <div class="row">
                <div class="col-xs-7" style="margin-right: 10px;">
                  <input type="text" id="e-book-search-table" class="form-control pull-right p-2 fw-bold" placeholder="Search">
                </div>
                <!-- <div class="col-xs-5" style="margin-right: 10px;">
                  <button class="btn btn-primary p-2 "  data-toggle="tooltip" data-original-title="Add E-books" onclick="add('e-books','lg')"> <i class="uil uil-plus-circle"></i>Add</button>
                </div> -->
              </div>
            </div>
            <div class="clearfix"></div>
          </div>
          
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover nowrap" id="student_table">
                <thead>
                <tr>
                  <th>Subject Name</th>
                  <th>Code</th>
                  <th>Assignment Name</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Total Marks</th>
                  <th>Obtained Marks</th>
                  <th>Reason</th>
                  <th>Teacher Status</th>
                  <th>Student Status</th>
                  <th>Teacher Assignment</th>
                  <th>Action</th>
                </tr>
                </thead>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    <!-- END PAGE CONTENT -->

    <script type="text/javascript">
        $(function() {
            var role = '<?= $_SESSION['Role'] ?>';
            var show = role == 'Administrator' ? true : false;
            var table = $('#student_table');

            var settings = {
                'processing': true,
                'serverSide': true,
                'serverMethod': 'post',
                'ajax': {
                    'url': '/app/assignments/student'
                },
                'columns': [{
                        data: "Name"
                    },
                    {
                        data: "Code"
                    },
                    {
                        data: "assignment_name"
                    },
                    {
                        data: "start_date"
                    },
                    {
                        data: "end_date"
                    },
                    {
                        data: "marks"
                    },
                    {
                        data: "obtained_mark"
                    },
                    {
                        data: "remark"
                    },
                    {
                        data: "status"
                    },
                    {
                        data: "assignment_submission_status"
                    },
                    {
              data: "file_path",
              render: function(data, type, row) {
                var path = '/lms-settings/';
                var file;
                if (row.File_Type && row.File_Type.toLowerCase() === 'pdf') {
                  // For PDF files
                  file = '<a href="' + path + data + '" download>Download PDF</a>';
                } else {
                  // For non-PDF files (assuming they are images)
                  file = '<a href="' + path + data + '" download><img src="' + path + data + '" height="50"></a>';
                }
                return file;
              }
            },
            {
  data: "file_name",
  render: function(data, type, row) {
    var uploadDir = '/student/lms/uploads/student_assignment/';
    var filePath = uploadDir + data;
    var button;

    // Check the status and file existence to determine which button to display
    if (row.status !== 'Rejected') 
    {
      if (data && row.file_exists) {
        button = '<a href="' + filePath + '" class="btn btn-info btn-sm" download>Download Student Assignment</a>';
      } else {
        button = '<button class="btn btn-primary btn-sm" data-toggle="modal" onclick=\'openUploadModal("' + row.id + '", "' + row.subject_id + '")\'>Upload Assignment</button>';

      }

    } else {
      button = '<button class="btn btn-warning btn-sm" data-toggle="modal" onclick=\'openUploadModal("' + row.id + '", "' + row.subject_id + '")\'>Reupload Assignment</button>';
      if (data && row.file_exists) {
        button = '<a href="' + filePath + '" class="btn btn-danger btn-sm" download>Download Updated Assignment</a>';
      }

    }

    return button;
  }
},

                ],
                "sDom": "<t><'row'<p i>>",
                "destroy": true,
                "scrollCollapse": true,
                "oLanguage": {
                    "sLengthMenu": "_MENU_ ",
                    "sInfo": "Showing <b>_START_ to _END_</b> of _TOTAL_ entries"
                },
                "aaSorting": [],
                "iDisplayLength":15,
            };
            table.dataTable(settings);
            // search box for table
            $('#e-book-search-table').keyup(function() {
              table.fnFilter($(this).val());
            });
          })
    </script>



<div class="modal fade" id="uploadModal" tabindex="-1" role="dialog" aria-labelledby="uploadModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="uploadModalLabel">Upload Assignment AnswerSheet</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="uploadForm" action="upload_assignment.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="uploaded_type" value="Online">
        <div class="modal-body">
          <!-- <div class="form-group">
                <label for="assignmentName">Assignment Name:</label>
                <input type="text" class="form-control" id="assignmentName" name="assignment_name" placeholder="Enter Your Assignment name" required>
              </div> -->
          <div class="form-group">
            <label for="assignmentFile">Select File (PDF, JPEG, JPG):</label>
            <input type="file" class="form-control-file" id="assignmentFile" name="assignment_file" accept=".pdf, .jpeg, .jpg" required>
          </div>
        </div>
        <div class="modal-footer">
          <input type="hidden" name="assignment_id">
          <input type="hidden" name="subject_id">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" name="upload_assignment" class="btn btn-primary">Upload</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript">
  function openUploadModal(assignmentId, subjectId) {
    // alert(assignmentId);
    // console.log(assignmentId);
    // console.log(subjectId);
    
    document.querySelector('input[name="assignment_id"]').value = assignmentId;
    document.querySelector('input[name="subject_id"]').value = subjectId;
    //document.querySelector('input[name="uploaded_type"]').value = uploadedtype;
    $('#uploadModal').modal('show'); // Assuming 'uploadModal' is the ID of your modal
  }
</script>
<?php include($_SERVER['DOCUMENT_ROOT'] . '/includes/footer-bottom.php'); ?>