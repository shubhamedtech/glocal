<?php

if (isset($_POST['upload_assignment'])) {
    // Database connection (assuming you have established a connection securely)
    $conn = new mysqli('localhost', 'root', '', 'updated_glocal');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    session_start();
    $student_id = $conn->real_escape_string($_SESSION['ID']);
    $subject_id = $conn->real_escape_string($_POST['subject_id']);
    $assignment_id = $conn->real_escape_string($_POST['assignment_id']);
    $uploaded_type = $conn->real_escape_string($_POST['uploaded_type']);

    // Directory where uploaded assignments will be stored
    $targetDir = "uploads/student_assignment/";

    // Ensure target directory exists
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0755, true); // Create directory recursively
    }

    // Check if file is uploaded without errors
    if ($_FILES["assignment_file"]["error"] == UPLOAD_ERR_OK) {
        $fileName = basename($_FILES["assignment_file"]["name"]);
        $targetFilePath = $targetDir .$fileName;

        // Get file extension
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowedTypes = array('pdf', 'jpeg', 'jpg');

        // Check if the uploaded file type is allowed
        if (!in_array($fileType, $allowedTypes)) {
            echo "Only PDF, JPEG, or JPG files are allowed.";
            exit;
        }

        // Move uploaded file to target directory
        if (move_uploaded_file($_FILES["assignment_file"]["tmp_name"], $targetFilePath)) {
            // File uploaded successfully, proceed with database operations
            //  $file_path_in_db = $targetDir . $fileName;
            $created_date = date('Y-m-d H:i:s');

            $existingData = $conn->query("SELECT * FROM submitted_assignment WHERE assignment_id='$assignment_id' AND student_id='$student_id' AND subject_id='$subject_id'");

            if ($existingData->num_rows > 0) {
                // Assignment already submitted, update the record
                $updated_query = $conn->query("UPDATE submitted_assignment SET file_name='$fileName', created_date='$created_date' WHERE assignment_id='$assignment_id' AND subject_id='$subject_id' AND student_id='$student_id'");
                if ($updated_query) {
                    // Record updated successfully
                    echo "<script>
                            alert('Assignment AnswerSheet Updated successfully.');
                            window.location.href = 'assignments.php'; // Redirect to another page
                          </script>";
                } else {
                    // Error occurred during update
                    echo "Error updating record: " . $conn->error;
                }
            } else {
                // New assignment submission, insert a new record
                $insert_query = $conn->query("INSERT INTO submitted_assignment (assignment_id, subject_id, student_id,uploaded_type, file_name, created_date) VALUES ('$assignment_id', '$subject_id', '$student_id', '$uploaded_type', '$fileName', '$created_date')");
                if ($insert_query) {
                    // Record inserted successfully
                    echo "<script>
                            alert('File uploaded successfully.');
                            window.location.href = 'assignments.php'; // Redirect to another page
                          </script>";
                } else {
                    // Error occurred during insert
                    echo "Error inserting record: " . $conn->error;
                }
            }
        } else {
            echo "Error moving uploaded file.";
        }
    } else {
        echo "File upload error.";
    }
}
