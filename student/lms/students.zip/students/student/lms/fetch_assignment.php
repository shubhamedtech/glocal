<?php
// Include database configuration and start session
// include '../../includes/db-config.php';

$hostname = "localhost";
$username = "root";
$password = "";
$database = "updated_glocal";

// Create connection
$conn = new mysqli($hostname, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();
// Retrieve session variables
$course_id = $_SESSION['Sub_Course_ID'];
$student_id = $_SESSION['ID'];
$current_sem = $_SESSION['Duration'];

// Build and execute database query
$syllabi_query = "SELECT sub_courses.ID, sub_courses.Mode_ID, sub_courses.Min_Duration, modes.Name as mode, syllabi.Name, syllabi.ID as subject_id
                  FROM syllabi
                  LEFT JOIN sub_courses ON syllabi.Sub_Course_ID = sub_courses.ID
                  LEFT JOIN modes ON sub_courses.Mode_ID = modes.ID
                  WHERE syllabi.Sub_Course_ID = $course_id AND syllabi.Semester = $current_sem";
$syllabi_result = mysqli_query($conn, $syllabi_query);
// print_r($syllabi_result);

$mysyllabi = [];
while ($row = mysqli_fetch_assoc($syllabi_result)) {
    $mysyllabi[] = $row['subject_id'];
}

// Handle DataTables AJAX request
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length'];
$searchValue = mysqli_real_escape_string($conn, $_POST['search']['value']);

// Prepare SQL query for fetching assignment records
$sql = "SELECT student_assignment.Assignment_id, student_assignment.assignment_name, student_assignment.start_date,
               student_assignment.end_date, student_assignment.marks, student_assignment.file_path,
               sub_courses.Name as course_name, sub_courses.Short_Name as course_short_name,
               syllabi.Name as subject_name, syllabi.Code
        FROM student_assignment
        LEFT JOIN sub_courses ON sub_courses.ID = student_assignment.sub_course_id
        LEFT JOIN syllabi ON syllabi.ID = student_assignment.subject_id
        WHERE student_assignment.subject_id IN ('" . implode("','", $mysyllabi) . "')";

// Apply search filter
if (!empty($searchValue)) {
    $sql .= " AND (syllabi.Name LIKE '%$searchValue%' OR sub_courses.Name LIKE '%$searchValue%' OR sub_courses.Short_Name LIKE '%$searchValue%')";
}

// Execute SQL query
$result = mysqli_query($conn, $sql);

$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = [
        "course_name" => $row["course_name"],
        "subject_code" => $row["Code"],
        "subject_name" => $row["subject_name"],
        "assignment_name" => $row["assignment_name"],
        "start_date" => $row["start_date"],
        "end_date" => $row["end_date"],
        "marks" => $row["marks"],
        "status" => 1,
        "ID" => $row["Assignment_id"],
    ];
}

// Total records without filtering
$totalRecords = mysqli_num_rows($result);

// Total records with filtering (considering search)
$totalRecordwithFilter = $totalRecords;

// Prepare JSON response
$response = [
    "draw" => intval($draw),
    "iTotalRecords" => $totalRecords,
    "iTotalDisplayRecords" => $totalRecordwithFilter,
    "aaData" => $data
];

// Return JSON response
echo json_encode($response);
