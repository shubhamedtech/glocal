
// echo $subQ = "SELECT syllabi.Code,syllabi.Name from syllabi WHERE syllabi.Course_ID = '".$_SESSION['Course_ID']."' AND syllabi.Sub_Course_ID  = '".$_SESSION['Sub_Course_ID']."' AND Semester='".$_SESSION['Duration']."' ";       
// die;


// $syllabi = "SELECT sub_courses.ID,sub_courses.Mode_ID,sub_courses.Min_Duration, modes.Name as mode ,syllabi.Name,syllabi.ID as subject_id from syllabi  LEFT JOIN sub_courses ON syllabi.Sub_Course_ID = sub_courses.ID LEFT JOIN modes ON sub_courses.Mode_ID = modes.ID  WHERE syllabi.Sub_Course_ID = $course_id AND syllabi.Semester=$current_sem";
// // print_r($syllabi);
// $syllabi = mysqli_query($conn, $syllabi);
// // print_r($syllabi);
// $mysyllabi = array();
// $subjectData = array();
// while ($row = mysqli_fetch_assoc($syllabi)) {
//   $mysyllabi[] = $row['subject_id'];
//   $subjectData[] = $row;
// }
// echo "<pre>";
// print_r($subjectData);

// die;


// Build and execute database query
$syllabi_query = "SELECT sub_courses.ID,sub_courses.Short_Name , sub_courses.Mode_ID, sub_courses.Min_Duration, modes.Name as mode, syllabi.Name, syllabi.ID as subject_id
                  FROM syllabi
                  LEFT JOIN sub_courses ON syllabi.Sub_Course_ID = sub_courses.ID
                  LEFT JOIN modes ON sub_courses.Mode_ID = modes.ID
                  WHERE syllabi.Sub_Course_ID = $course_id AND syllabi.Semester = $current_sem";
$syllabi_result = mysqli_query($conn, $syllabi_query);
// print_r($syllabi_result);

$mysyllabi = [];
while ($row = mysqli_fetch_assoc($syllabi_result)) {
  $mysyllabi[] = $row['subject_id'];
}
// print_r($mysyllabi);
// Handle DataTables AJAX request
// $draw = $_POST['draw'];
// $row = $_POST['start'];
// $rowperpage = $_POST['length'];
// $searchValue = mysqli_real_escape_string($conn, $_POST['search']['value']);

// Prepare SQL query for fetching assignment records
$sql = "SELECT student_assignment.Assignment_id, student_assignment.assignment_name, student_assignment.start_date,
               student_assignment.end_date, student_assignment.marks, student_assignment.file_path,
               sub_courses.Name as course_name, sub_courses.Short_Name as course_short_name,
               syllabi.Name as subject_name, syllabi.Code
        FROM student_assignment
        LEFT JOIN sub_courses ON sub_courses.ID = student_assignment.sub_course_id
        LEFT JOIN syllabi ON syllabi.ID = student_assignment.subject_id
        WHERE student_assignment.subject_id IN ('" . implode("','", $mysyllabi) . "')";
// echo json_encode($sql);

// Apply search filter
if (!empty($searchValue)) {
  $sql .= " AND (syllabi.Name LIKE '%$searchValue%' OR sub_courses.Name LIKE '%$searchValue%' OR sub_courses.Short_Name LIKE '%$searchValue%')";
}
// Execute SQL query
$result = mysqli_query($conn, $sql);
// print_r($result);
$data = [];
// print_r($data);
while ($row = mysqli_fetch_assoc($result)) {
  $data[] = [
    "course_name" => $row["course_name"],
    "subject_code" => $row["Code"],
    "subject_name" => $row["subject_name"],
    "assignment_name" => $row["assignment_name"],
    "start_date" => $row["start_date"],
    "end_date" => $row["end_date"],
    "marks" => $row["marks"],
    "status" => 1,
    "ID" => $row["Assignment_id"],
  ];
}
// print_r($data);
// Total records without filtering
$totalRecords = mysqli_num_rows($result);
// print_r($totalRecords);

// Total records with filtering (considering search)
$totalRecordwithFilter = $totalRecords;

// Prepare JSON response
// $response = [
//   "draw" => intval($draw),
//   "iTotalRecords" => $totalRecords,
//   "iTotalDisplayRecords" => $totalRecordwithFilter,
//   "aaData" => $data
// ];
// echo "<pre>";
// print_r($response);

// Return JSON response
// echo json_encode($response);
<div class="page-container ">

  // session_start();
  // echo "<pre>";
  //   print_r($_SESSION); die;

  // $course_id=$_SESSION['Sub_Course_ID'];
  // $student_id=$_SESSION['ID'];

  // $current_sem=$_SESSION['Duration'];



  // $syllabi = "SELECT sub_courses.ID,sub_courses.Mode_Id,sub_courses.Min_Duration, modes.Name as mode ,syllabi.Name,syllabi.ID as subject_id from syllabi  LEFT JOIN sub_courses ON syllabi.Sub_Course_ID = sub_courses.ID LEFT JOIN modes ON sub_courses.Mode_Id = modes.ID  WHERE syllabi.Sub_Course_ID = $course_id AND syllabi.Semester=$current_sem";
  // $syllabi = mysqli_query($conn, $syllabi);
  // $mysyllabi=array();
  // $subjectData=array();
  // while ($row = mysqli_fetch_assoc($syllabi)) {
  //   $mysyllabi[]= $row['subject_id'];
  //   $subjectData[]=$row;
  // }

  // echo "<pre>";
  // print_r($subjectData); die;
  ?>
<div class="page-content-wrapper ">
    <div class="content ">
      <div class="jumbotron" data-pages="parallax">
        <div class=" container-fluid sm-p-l-0 sm-p-r-0">

        </div>
      </div>

      <div class=" container-fluid">
        <div class="card card-transparent">
          <div class="card-header">

            <?php
            $breadcrumbs = array_filter(explode("/", $_SERVER['REQUEST_URI']));
            for ($i = 1; $i <= count($breadcrumbs); $i++) {
              if (count($breadcrumbs) == $i) : $active = "active";
                $crumb = explode("?", $breadcrumbs[$i]);
                echo $crumb[0];
              endif;
            }
            ?>

            <div class="pull-right">
              <div class="row">
                <div class="col-xs-7" style="margin-right: 10px;">
                  <input type="text" id="e-book-search-table" class="form-control pull-right p-2 fw-bold" placeholder="Search">
                </div>
                <div class="col-xs-5" style="margin-right: 10px;">
                  <button class="btn btn-primary p-2 " data-toggle="tooltip" data-original-title="Add E-books" onclick="add('e-books','lg')"> <i class="uil uil-plus-circle"></i>Add</button>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
          </div>




          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover nowrap" id="e_books-table">
                <thead>
                  <tr>
                    <th>Subject Code</th>
                    <th>Subject Name</th>
                    <th>Start Date</th>
                    <th>End date</th>
                    <th>Total Marks</th>
                    <th>Obtained Marks</th>
                    <th>Assignment</th>
                    <th>status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  foreach ($subjectData as $key => $value) { ?>
                    <tr>
                      <td><?= $value[''] ?></td>
                      <td><?= $value[''] ?></td>
                      <td><?= $value[''] ?></td>
                      <td><?= $value[''] ?></td>
                      <td><?= $value[''] ?></td>
                    </tr>

                  <?php    }

                  ?>
                  <tr></tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>







<script type="text/javascript">
      $(function() {
        // var role = '<?= $_SESSION['Role'] ?>';
        // var show =  true ;
        var table = $('#e_books-table');
        // print_r(table);
        var settings = {
          'processing': true,
          'serverSide': true,

          'serverMethod': 'post',
          'ajax': {
            'url': '/student/lms/assignments',

            //                   }
          },
          'columns': [{
              data: "subject_code"
            },
            {
              data: "subject_name"
            },
            {
              data: "assignment_name"
            },
            {
              data: "start_date"
            },
            {
              data: "end_date"
            },
            {
              data: "marks"
            },
            {
              data: "obtained_marks"
            },
            {
              data: "file_path"
            },
            {
              data: "status",
              "render": function(data, type, row) {
                var active = data == 1 ? 'Active' : 'Inactive';
                var checked = data == 1 ? 'checked' : '';
                return '<div class="form-check form-check-inline switch switch-lg success">\
                                <input onclick="changeStatus(' + "'e_books'" + ', ' + row.ID + ',' + "'status'" + ')" type="checkbox" ' + checked + ' id="status-switch-' + row.ID + '">\
                                <label for="status-switch-' + row.ID + '">' + active + '</label>\
                              </div>';
              }
            },
            {
              data: "ID",
              "render": function(data, type, row) {
                return '<div class="button-list text-end">\
                        <i class="uil uil-trash icon-xs cursor-pointer" onclick="changeStatus(' + "'e_books'" + ', ' + data + ',' + "'status'" + ',2)"></i>\
                      </div>'
              }
            },
          ],
          "sDom": "<t><'row'<p i>>",
          "destroy": true,
          "scrollCollapse": true,
          "oLanguage": {
            "sLengthMenu": "_MENU_ ",
            "sInfo": "Showing <b>_START_ to _END_</b> of _TOTAL_ entries"
          },
          "aaSorting": [],
          "iDisplayLength": 9,
        };

        // alert('confirm');
        table.dataTable(settings);
        // search box for table
        $('#e-book-search-table').keyup(function() {
          table.fnFilter($(this).val());
        });
      })
    </script>
        <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/jquery.dataTables.min.js"></script>
    <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/css/jquery.dataTables_themeroller.css">
/////////////////////////////////


















<form id="resultForm" action="update_result.php" method="POST" enctype="multipart/form-data">
    <input type="text" name="assignment_id" value="<?php echo $assignment_id; ?>">
    <div class="form-group">
        <label for="uploadedType">Uploaded Type</label> 
        <select class="form-control" id="uploadedType" name="uploaded_type">
            <option value="submitted" <?php if ($uploaded_type == 'submitted') echo 'selected'; ?>>Submitted</option>
            <option value="manual" <?php if ($uploaded_type == 'manual') echo 'selected'; ?>>Manual</option>
            <option value="online" <?php if ($uploaded_type == 'online') echo 'selected'; ?>>Online</option>
        </select>
    </div> 
    <div class="form-group">
        <label for="status">Status</label>
        <select class="form-control" id="status" name="status">
            <option value="1" <?php if ($status == '1') echo 'selected'; ?>>Submitted</option>
            <option value="2" <?php if ($status == '2') echo 'selected'; ?>>Approved</option>
            <option value="3" <?php if ($status == '3') echo 'selected'; ?>>Rejected</option>
        </select>
    </div>
    <div class="form-group">
        <label for="marksInput">Enter Marks</label>
        <input type="number" class="form-control" id="marksInput" value="<?php echo $marks; ?>"  name="marks" placeholder="Enter Marks"  required>
    </div>
    <div class="form-group">
        <label for="reasonInput">Enter Reason (Comment)</label>
        <input type="text" class="form-control" id="reasonInput" name="reason" placeholder="Enter Reason" value="<?php echo $reason; ?>" required>
    </div>
    <div class="form-group">
        <label for="teacherUpdatedAssignment">Assignment Solutions</label>
        <input type="file" class="form-control" id="teacherUpdatedAssignment" name="teacher_updated_assignment" placeholder="Assignment Solutions" required>
    </div>
    <button type="submit" class="btn btn-primary btn-custom">Submit</button>
    <button type="button" class="btn btn-secondary btn-custom" data-dismiss="modal">Close</button>
</form>