<?php

if (isset($_POST['university_id']) && isset($_POST['course']) && isset($_POST['duration']) && isset($_POST['subject']) || isset($_POST['chapter_code']) && isset($_POST['unit_code'])) {
  require '../../includes/db-config.php';
  session_start();

  $university_id = intval($_POST['university_id']);
  $sub_course = intval($_POST['course']);
  $subject_id = intval($_POST['subject']);
  $duration = intval($_POST['duration']);
  $chapter_name_arr = is_array($_POST['chapter_name']) ? array_filter($_POST['chapter_name']) : [];
  $chapter_code_arr = is_array($_POST['chapter_code']) ? array_filter($_POST['chapter_code']) : [];
  $unit_name_arr = is_array($_POST['unit_name']) ? array_filter($_POST['unit_name']) : [];
  $unit_code_arr = is_array($_POST['unit_code']) ? array_filter($_POST['unit_code']) : [];
  $topic_name_arr = is_array($_POST['topic_name']) ? array_filter($_POST['topic_name']) : [];
        echo "<pre>";
        print_r($unit_name_arr);die;
  foreach ($chapter_name_arr as $chapter_key => $chapter_name) {
    $chapter_code = $chapter_code_arr[$chapter_key];

    $addchapter = $conn->query("INSERT INTO Chapter (Name,Code,University_ID,Sub_Course_ID,Semester,Subject_ID) VALUE('".$chapter_name. "','" .$chapter_code. "',$university_id,$sub_course,'" . $duration . "',$subject_id)");
    $chapter_id = $conn->insert_id;
    foreach ($unit_name_arr[$chapter_key] as $unit_key => $unit_name) {
      if ($unit_key == $chapter_key) {
        $unit_code = $unit_code_arr[$chapter_key][$unit_key];
        // echo "<pre>";
        // print_r($unit_code);
        // echo "INSERT INTO Chapter_Units (Name,Code,Chapter_ID) VALUE('" .$unit_name."','".$unit_code."',$chapter_id)";
        $chapterUnit = $conn->query("INSERT INTO Chapter_Units (Name,Code,Chapter_ID) VALUE('" .$unit_name."','".$unit_code."',$chapter_id)");
        $unit_id = $conn->insert_id;
        if (isset($topic_name_arr[$chapter_key][$unit_key])) {
          foreach ($topic_name_arr[$chapter_key][$unit_key] as $chapter_key => $topic_name) {
            $addUnitTopic = $conn->query("INSERT INTO Chapter_Units_Topics (Name,Unit_ID,Chapter_ID) VALUE('" .$topic_name. "','$unit_id',$chapter_id)");
          }
        }
      }
    }
  }

  if (isset($addUnitTopic) && $addUnitTopic) {
    echo json_encode(['status' => 200, 'message' => 'Syllabus added successlly!']);
  } else {
    echo json_encode(['status' => 400, 'message' => 'Something went wrong!']);
  }
} else {
  echo json_encode(['status' => 400, 'message' => 'Something went wrong!']);
}


