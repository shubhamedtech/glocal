<?php

if (isset($_POST['university_id']) && isset($_POST['course']) && isset($_POST['duration']) && isset($_POST['subject']) || isset($_POST['chapter_code']) && isset($_POST['unit_code'])) {
  require '../../includes/db-config.php';
  session_start();

  $university_id = intval($_POST['university_id']);
  $sub_course = intval($_POST['course']);
  $subject_id = intval($_POST['subject']);
  $duration = mysqli_real_escape_string($conn, $_POST['duration']);
  $chapter_name_arr = is_array($_POST['chapter_name']) ? array_filter($_POST['chapter_name']) : [];
  $chapter_code_arr = is_array($_POST['chapter_code']) ? array_filter($_POST['chapter_code']) : [];
  $unit_name_arr = is_array($_POST['unit_name']) ? array_filter($_POST['unit_name']) : [];
  $unit_code_arr = is_array($_POST['unit_code']) ? array_filter($_POST['unit_code']) : [];
  $topic_name_arr = is_array($_POST['topic_name']) ? array_filter($_POST['topic_name']) : [];
  // $chapter_id_arr = is_array($_POST['chapter_id']) ? array_filter($_POST['chapter_id']) : [];
  // $chapter_ids = implode(',', $chapter_id_arr);

  $addchapter = false;
  $chapterUnit = false;
  $addUnitTopic = false;
  $updateChapter = false;
  $updateUnit = false;
  $updateUnitTopic = false;




  $edit_chapter_arr = array_filter($chapter_name_arr, function ($value, $key) {
    return $key !== 'name';
  }, ARRAY_FILTER_USE_BOTH);

  $add_chapter_arr = array_filter($chapter_name_arr, function ($value, $key) {
    return $key == 'name';
  }, ARRAY_FILTER_USE_BOTH);

  $edit_chapter_code_arr = array_filter($chapter_code_arr, function ($value, $key) {
    return $key !== 'code';
  }, ARRAY_FILTER_USE_BOTH);

  $add_chapter_code_arr = array_filter($chapter_code_arr, function ($value, $key) {
    return $key == 'code';
  }, ARRAY_FILTER_USE_BOTH);




  // edit
// echo '<pre>';
  if (is_array($edit_chapter_arr) && !empty($edit_chapter_arr)) {

    foreach ($edit_chapter_arr as $chapter_id => $chapter_name) {
      $chapter_name = $chapter_name[0];
      $chapter_code = $edit_chapter_code_arr[$chapter_id][0];
      $checkChapter = $conn->query("SELECT ID FROM Chapter WHERE  ID = $chapter_id");
      if ($checkChapter->num_rows > 0) {

        $updateChapter = $conn->query("UPDATE Chapter SET Name = '$chapter_name', Code = '$chapter_code' WHERE ID = $chapter_id");
      }
      
      if (isset($unit_name_arr[$chapter_id]) && is_array($unit_name_arr[$chapter_id]) && array_key_exists('uedit', $unit_name_arr[$chapter_id])) {
        foreach ($unit_name_arr[$chapter_id]['uedit'] as $unit_key => $unit_name) {
          $unit_code = $unit_code_arr[$chapter_id]['uedit'][$unit_key][0];
          $unit_name = $unit_name_arr[$chapter_id]['uedit'][$unit_key][0];
          $updateUnit = $conn->query("UPDATE Chapter_Units SET Name = '$unit_name', Code = '$unit_code' WHERE ID = $unit_key AND Chapter_ID = $chapter_id");
          $updatedUnitKeys[] = $unit_key;
        }
        $i = 0; 
        foreach($topic_name_arr[$chapter_id] as $unitid=>$topicarr)
          {
            if($unitid==$updatedUnitKeys[$i] && array_key_exists('tedit',$topicarr))
            {
              //edit
              if (isset($topicarr) && is_array($topicarr) && array_key_exists('tedit', $topicarr)) {
                ;
                foreach ($topicarr['tedit'] as $topic_key => $topic_name) {
                  $updateUnitTopic = $conn->query("UPDATE Chapter_Units_Topics SET Name = '$topic_name', Unit_ID =$updatedUnitKeys[$i],Chapter_ID=$chapter_id WHERE ID = $topic_key");
                }    
              }
            }
            else
            {
              // //add   with unit_key(DB key)
              if (count($topic_name_arr[$chapter_id][$unitid]) > 0 && array_key_exists('tadd',$topicarr)) {
                foreach ($topic_name_arr[$chapter_id][$unitid]['tadd'] as $topic_key => $topic_name) {
                  $topic_name = $topic_name_arr[$chapter_id][$unitid]['tadd'][$topic_key];
                   $addUnitTopic = $conn->query("INSERT INTO Chapter_Units_Topics (Name,Unit_ID,Chapter_ID) VALUES('" . $topic_name . "', $updatedUnitKeys[$i], $chapter_id)");

                }
              }
            }
            $i++;
          }

        unset($unit_name_arr[$chapter_id]['uedit']);
        unset($unit_code_arr[$chapter_id]['uedit']);
        if (count($unit_name_arr[$chapter_id]) > 0) {
          foreach ($unit_name_arr[$chapter_id] as $unit_id => $unit_name) {
            $unit_code = $unit_code_arr[$chapter_id][$unit_id]['uadd'][0];
            $unit_name = $unit_name_arr[$chapter_id][$unit_id]['uadd'][0];
            $insertUnit = $conn->query("INSERT INTO Chapter_Units (Name, Code, Chapter_ID) VALUES('$unit_name', '$unit_code', $chapter_id)");
          }
        }
      }
    }
  }
  // addd
  if (is_array($add_chapter_arr) && !empty($add_chapter_arr)) {
    foreach ($add_chapter_arr['name'] as $chapter_key => $chapter_name) {
      $chapter_code = $add_chapter_code_arr['code'][$chapter_key][0];
      $chapter_name = $chapter_name[0];
      $addchapter = $conn->query("INSERT INTO Chapter (Name,Code,University_ID,Sub_Course_ID,Semester,Subject_ID) VALUES('" . $chapter_name . "','" . $chapter_code . "',$university_id,$sub_course,'" . $duration . "',$subject_id)");
      $chapter_id = $conn->insert_id;
      if (isset($unit_name_arr[$chapter_key]) && is_array($unit_name_arr[$chapter_key])) {
        foreach ($unit_name_arr[$chapter_key] as $unit_key => $unit_name) {
          $unit_code = $unit_code_arr[$chapter_key][$unit_key]['uadd'][0];
          $unit_name = $unit_name_arr[$chapter_key][$unit_key]['uadd'][0];
          $insertUnit = $conn->query("INSERT INTO Chapter_Units (Name, Code, Chapter_ID) VALUES('$unit_name', '$unit_code', $chapter_id)");
          $unit_id = $conn->insert_id;
          if (isset($topic_name_arr[$chapter_key][$unit_key]) && is_array($topic_name_arr[$chapter_key][$unit_key])) {
            foreach ($topic_name_arr[$chapter_key][$unit_key] as $topic_key => $topic_name) {
              $topic_name = $topic_name_arr[$chapter_key][$unit_key]['tadd'][0];
              $addUnitTopic = $conn->query("INSERT INTO Chapter_Units_Topics (Name,Unit_ID,Chapter_ID) VALUES('" . $topic_name . "', $unit_id, $chapter_id)");
            }

          }

        }
      }
    }
  }

  if ($addchapter || $chapterUnit || $addUnitTopic ) {
    echo json_encode(['status' => 200, 'message' => 'Syllabus added successfully!']);
  } else if($updateChapter || $updateUnit || $updateUnitTopic ){
    echo json_encode(['status' => 200, 'message' => 'Syllabus Updated successfully!']);
    
  }else{
    echo json_encode(['status' => 400, 'message' => 'Something went wrong!']);
  }
} else {
  echo json_encode(['status' => 400, 'message' => 'Missing required fields!']);
}

