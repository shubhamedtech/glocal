<link href="../../assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" media="screen" />
<link href="../../assets/plugins/bootstrap-tag/bootstrap-tagsinput.css" rel="stylesheet" type="text/css" />
<!-- Modal -->
<div class="modal-header clearfix text-left">
  <button aria-label="" type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-icon">close</i>
  </button>
  <h5>Add <span class="semi-bold">Syllabus</span></h5>
</div>
<style>
  .modal-dialog.modal-lg {
    width: 100% !important;
  }

  .card-body {
    padding: 15px;
  }

  .card {
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);
    border-radius: 2px !important;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    -webkit-transition: all 0.2s ease;
    transition: all 0.2s ease;
    border: 1px solid transparent;
    position: relative;
    margin-bottom: 20px;
    width: 100%;
    word-wrap: none;
    background: #fff;
  }
</style>

<?php
require '../../includes/db-config.php';
session_start();
?>
<form role="form" id="form-add-sub-course" action="/app/syllabus/store" method="POST" enctype="multipart/form-data">
  <div class="modal-body">
    <div class="row">
      <div class="col-md-6">
        <div class="form-group form-group-default required">
          <label>University</label>
          <select class="full-width" style="border: transparent;" id="university_id" name="university_id"
            onchange="getDetails(this.value);">
            <option value="">Choose</option>
            <?php

            $university_query = $_SESSION['Role'] != 'Administrator' ? " AND ID =" . $_SESSION['university_id'] : '';
            $universities = $conn->query("SELECT ID, CONCAT(Universities.Short_Name, ' (', Universities.Vertical, ')') as Name FROM Universities WHERE ID IS NOT NULL $university_query");
            while ($university = $universities->fetch_assoc()) { ?>
              <option value="<?= $university['ID'] ?>"><?= $university['Name'] ?></option>
            <?php } ?>
          </select>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-group form-group-default required">
          <label>Specialization</label>
          <select class="full-width" style="border: transparent;" id="course" name="course"
            onchange="getDuration(this.value)">
            <option value="">Choose</option>
          </select>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 skillTab">
        <div class="form-group form-group-default required">
          <label>Category</label>
          <select class="full-width" style="border: transparent;" id="category" name="category"
            onchange="getSubject(this.value)">
            <option value="">Choose Category</option>
            <option value="3">3 Months</option>
            <option value="6/certified">6 Months Certified</option>
            <option value="11/certified">11 Months Certified</option>
            <option value="11/advanced">11 Months Advance Diploma</option>
          </select>
        </div>
      </div>
      <div class="col-md-6 semesterTab">
        <div class="form-group form-group-default required">
          <label>Semester</label>
          <select class="full-width" style="border: transparent;" id="semester" name="semester"
            onchange="getSubject(this.value) ">
          </select>
        </div>
      </div>
      <div class="col-md-6 ">
        <div class="form-group form-group-default required">
          <label>Subjects</label>
          <select class="full-width" style="border: transparent;" id="subject" name="subject">
          </select>
        </div>
      </div>
    </div>
    <!-- start kp -->
    <div class="row" style="float: right;">
      <div class="btn btn-outline-primary rounded add-more mb-3">
        <i class=" uil uil-plus-circle icon-xs cursor-pointer mt-1 ms-0 pe-2"></i> Add Chapter
      </div>
    </div>
    <!-- <div class="row card card-body mb-3">
      <div class="control-group input-group" style="display: inline ">
        <h4 class="mt-0">Chapter 1</h4>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group form-group-default required">
              <label>Chapter Name</label>
              <input type="text" name="chapter_name[]" class="form-control" placeholder="ex: Introduction of Technology"
                value="" required>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group form-group-default required">
              <label>Chapter Code</label>
              <input type="number" name="chapter_code[]" class="form-control" placeholder="ex: 123" value="" required>
            </div>
          </div>
        </div>
        <div class="unit-section">
          <h4 class="mt-0">Unit 1</h4>
          <div class="row">
            <div class="col-md-5">
              <div class="form-group form-group-default required">
                <label>Unit Name</label>
                <input type="text" name="unit_name[]" class="form-control" placeholder="ex: Introduction of Technology"
                  value="" required>
              </div>
            </div>
            <div class="col-md-5">
              <div class="form-group form-group-default required">
                <label>Unit Code</label>
                <input type="number" name="unit_code[]" class="form-control" placeholder="ex: UNI123" value="" required>
              </div>
            </div>
            <div class="col-md-2">
              <div class="btn btn-outline-primary rounded add-more-unit mb-3">
                + Add Unit
              </div>
            </div>
          </div>
        </div>
        <div class="after-add-more-unit">
        </div>
      </div>
    </div> -->
    <div class=" after-add-more">
    </div>
    <!-- end kp -->
  </div>
  <div class="modal-footer clearfix text-end">
    <div class="col-md-4 m-t-10 sm-m-t-10">
      <button aria-label="" type="submit" class="btn btn-primary btn-cons btn-animated from-left">
        <span>Save</span>
        <span class="hidden-block">
          <i class="pg-icon">tick</i>
        </span>
      </button>
    </div>
  </div>
</form>


<script type="text/javascript" src="../../assets/plugins/select2/js/select2.full.min.js"></script>
<script type="text/javascript">

$(document).ready(function () {
    var chapterCount = 2;  // Chapter starts from 2
    var unitCount = {};

    // Add more chapters
    $(".add-more").click(function () {
        var html = `
            <div class="row control1 card card-body mb-3">
              <h4 class="mt-0 ">Chapter ${chapterCount}</h4>
              <div class="control-group input-group" style="margin-top:10px">
                <div class="col-md-5">
                  <div class="form-group form-group-default required">
                    <label>Chapter Name</label>
                    <input type="text" name="chapter_name[]" class="form-control" placeholder="ex: Introduction of Technology" value=""
                      required>
                  </div>
                </div>
                <div class="col-md-5">
                  <div class="form-group form-group-default required">
                    <label>Chapter Code</label>
                    <input type="number" name="chapter_code[]" class="form-control" placeholder="ex: UNI123" value="" required>
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="input-group-btn">
                    <a class="remove" type="button"><i class="uil uil-minus-circle icon-xs cursor-pointer"></i></a>
                  </div>
                </div>
              </div>
              <!-- Unit Section -->
              <div class="unit-section" id="unit-section-${chapterCount}">
                <h4 class="mt-0">Unit 1</h4>
                <div class="row">
                  <div class="col-md-5">
                    <div class="form-group form-group-default required">
                      <label>Unit Name</label>
                      <input type="text" name="unit_name[${chapterCount}][]" class="form-control" placeholder="ex: Introduction of Technology"
                        value="" required>
                    </div>
                  </div>
                  <div class="col-md-5">
                    <div class="form-group form-group-default required">
                      <label>Unit Code</label>
                      <input type="number" name="unit_code[${chapterCount}][]" class="form-control" placeholder="ex: UNI123" value="" required>
                    </div>
                  </div>
                  <div class="col-md-2">
                    <div class="btn btn-outline-primary rounded add-more-unit mb-3" data-chapter="${chapterCount}">
                      + Add Unit
                    </div>
                  </div>
                </div>
              </div>
              <div class="after-add-more-unit" id="after-add-more-unit-${chapterCount}"></div>
            </div>`;
        $(".after-add-more").append(html);
        unitCount[chapterCount] = 2; // Initialize unit count for this chapter
        chapterCount++;
    });

    // Remove chapters
    $("body").on("click", ".remove", function () {
        $(this).parents(".control1").remove();
    });

    // Add more units to a specific chapter
    $("body").on("click", ".add-more-unit", function () {
        var chapter = $(this).data("chapter");
        var unit_html = `
            <div class="unit-section unit-control">
              <h4 class="mt-0">Unit ${unitCount[chapter]}</h4>
              <div class="row">
                <div class="col-md-5">
                  <div class="form-group form-group-default required">
                    <label>Unit Name</label>
                    <input type="text" name="unit_name[${chapter}][]" class="form-control" placeholder="ex: Introduction of Technology" value="" required>
                  </div>
                </div>
                <div class="col-md-5">
                  <div class="form-group form-group-default required">
                    <label>Unit Code</label>
                    <input type="number" name="unit_code[${chapter}][]" class="form-control" placeholder="ex: UNI123" value="" required>
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="input-group-btn">
                    <a class="remove-unit" type="button"><i class="uil uil-minus-circle icon-xs cursor-pointer"></i></a>
                  </div>
                </div>
              </div>
            </div>`;
        $(`#after-add-more-unit-${chapter}`).append(unit_html);
        unitCount[chapter]++;
    });

    // Remove units
    $("body").on("click", ".remove-unit", function () {
        $(this).parents(".unit-control").remove();
    });

});

</script>
<script>
  $(function () {
    $("#eligibilities").select2();
    $("#course_category").select2();
    $(".skillTab, .semesterTab").hide();
  })

  function getDetails(id) {
    if (id == 47) {
      $(".skillTab").hide();
      $(".semesterTab").show();
      getDuration();
    } else {
      $(".skillTab").show();
      $(".semesterTab").hide();
    }
    $.ajax({
      url: '/app/syllabus/courses?id=' + id,
      type: 'GET',
      success: function (data) {
        $('#course').html(data);
      }
    });
  }

  function getDuration(id) {
    $.ajax({
      url: '/app/syllabus/semester?id=' + id,
      type: 'GET',
      success: function (data) {
        $('#semester').html(data);
      }
    });
  }

  function getSubject(duration) {
    var sub_course_id = $("#course").val();
    var university_id = $("#university_id").val();
    $.ajax({
      url: '/app/syllabus/subjects?id=' + sub_course_id + '&university_id=' + university_id + '&duration=' + duration,
      type: 'GET',
      success: function (data) {
        $('#subject').html(data);
      }
    });
  }

  $(function () {
    $('#form-add-sub-course').validate({
      rules: {
        name: {
          required: true
        },
        short_name: {
          required: true
        },
        university_id: {
          required: true
        },
        course: {
          required: true
        },
      },
      highlight: function (element) {
        $(element).addClass('error');
        $(element).closest('.form-control').addClass('has-error');
      },
      unhighlight: function (element) {
        $(element).removeClass('error');
        $(element).closest('.form-control').removeClass('has-error');
      }
    });
  })

  $("#form-add-sub-course").on("submit", function (e) {
    if ($('#form-add-sub-course').valid()) {
      $(':input[type="submit"]').prop('disabled', true);
      var formData = new FormData(this);
      $.ajax({
        url: this.action,
        type: 'post',
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function (data) {
          if (data.status == 200) {
            $('.modal').modal('hide');
            notification('success', data.message);
            $('#sub-courses-table').DataTable().ajax.reload(null, false);
          } else {
            $(':input[type="submit"]').prop('disabled', false);
            notification('danger', data.message);
          }
        }
      });
      e.preventDefault();
    }
  });

</script>